
mgLunch! is a MSX ROM launcher for the  "KdL firmware's OneChip MSX"

v1.2f :

USAGE

mgLunch.com - mgLunch! for OCM
mglOcm.com  - romloader for OCM
mglCook.exe - rom file scanner for Windows xp/vista/7/8/8.1/10

[F1] Search : Search Rom File
[F2] FavBnk : Change to Favorite section
[F3] AddFav : Add to Favorite
[F4] RmvFav : Remove from Favorite
[F5] Help
[F10] Exit to DOS
[SPACE] : File Select Mode
[0]~[Z] : Fast Change File Section
[CTRL]+[CURSOR] : Fast Cursor Scroll

...And more some command options are as below in 'File Select Mode'

[RETURN] = Execute Rom file
[k] = forced execute rom on Konami classic Mapper - faster than autodetect
[s] = forced execute rom on Konami-SCC Mapper - faster than autodetect
[8] = forced execute rom on Ascii-8 Mapper - faster than autodetect
[f] = forced execute rom on Ascii16 Mapper - faster than autodetect
[o] = game master option
[t] = Z80B 5.37MHz Panasonic Turbo mode -
[r] = Execute rom file by alternate method

REQUIREMENTS

MSX-DOS2, Nextor, KdL firmware v3.1 (or above)


'mgLunch' , "mglOcm", "mglCook" are written by ToughkidCST


CONTACT
toughkidcst@gmail.com